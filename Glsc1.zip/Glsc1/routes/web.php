<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function(){
    $Hero = [
        [
           'Name'     => 'Zilong',
           'Image'    => 'https://dailyspin.id/wp-content/uploads/2021/01/zilong-revamped-mobile-legends-project-next-uhdpaper.com-hd-5.2884.jpg',
           'Role'     => 'Assassin',
           'RecLane'  => 'Explane'
        ],
        [
            'Name'    => 'Lylia',
            'Image'   => 'https://dailyspin.id/wp-content/uploads/2021/02/Lylia-ML.jpg',
            'Role'    => 'Mage',
            'RecLane' => 'Midlane'
        ],
        [
            'Name'    => 'Beatrix',
            'Image'   => 'https://dailyspin.id/wp-content/uploads/2021/03/beatrix-x-factor-mobile-legends-skin.jpg',
            'Role'    => 'Marksman',
            'RecLane' => 'Goldlane'
        ],
        [
            'Name'    => 'Balmond',
            'Image'   => 'https://dailyspin.id/wp-content/uploads/2020/08/Balmond.jpg',
            'Role'    => 'Fighter',
            'RecLane' => 'Jungle'
        ],
        [
            'Name'    => 'Estes',
            'Image'   => 'https://dailyspin.id/wp-content/uploads/2020/06/estes72.jpg',
            'Role'    => 'Support',
            'RecLane' => 'Roam'
        ],
        [
            'Name'    => 'Akai',
            'Image'   => 'https://dailyspin.id/wp-content/uploads/2022/03/Revamp-Akai-ML.jpg',
            'Role'    => 'Tank',
            'RecLane' => 'Jungle, Roam, Explane'
        ]
        
   
     ];
    return view('home', compact('Hero'));
});
